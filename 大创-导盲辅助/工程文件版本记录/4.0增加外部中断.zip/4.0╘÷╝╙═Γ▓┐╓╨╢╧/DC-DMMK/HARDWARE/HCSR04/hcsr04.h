#ifndef __HCSR04_H
#define __HCSR04_H

float Hcsr04GetLength(void);
float Hcsr04GetLength1(void);
float Hcsr04GetLength2(void);
void Hcsr04Init(void);

#endif
